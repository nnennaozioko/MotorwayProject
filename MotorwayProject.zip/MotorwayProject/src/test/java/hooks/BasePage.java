package hooks;

import utilities.OptionManager;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.Properties;

public class BasePage {

    // Using ThreadLocal for thread-safe WebDriver instance
    public static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<>();
    public Properties prop;
    public OptionManager op;

    // Method to get WebDriver instance
    public static WebDriver getDriver() {
        return tlDriver.get();
    }

    @Before
    public void setUp() {
        // Initialize properties and OptionManager
        prop = new Properties();
        // Assuming properties are loaded from a file or other source
        // Example: prop.load(new FileInputStream("path/to/config.properties"));

        // Here prop should be initialized with actual property values.
        // Example: prop.load(new FileInputStream("path/to/config.properties"));

        op = new OptionManager(prop);
        //String Browser = prop.getProperty("browser");
        //if(Browser.equalsIgnoreCase("chrome")) {
        // Initialize the WebDriver with ChromeOptions
        tlDriver.set(new ChromeDriver(op.getChromeOptions()));
        getDriver().manage().window().maximize();





    }

    @After
    public void tearDown() {
        if (getDriver() != null) {
          //  getDriver().quit();
            // tlDriver.remove();
        }
    }
}