package pageObjects;

import hooks.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class CarValuationPage {

    private final WebDriver driver;
    BasePage basePage = new BasePage();

    private final By carRegistration = By.xpath("(//div//input[@type='text'])[1]");
    private final By valueYourCar = By.xpath("(//span[text()='Value your car'])[1]");
    private final By carDetails = By.id("result-details-id");

    public CarValuationPage(WebDriver driver) {
        this.driver = driver;
    }

    public void fillCarRegistration(String registration) {
        driver.findElement(carRegistration).clear();
        driver.findElement(carRegistration).sendKeys(registration);
    }

    public void clickValueYourCar() {
        driver.findElement(valueYourCar).click();
    }

    public String getCarDetails() {
        return driver.findElement(carDetails).getText();
    }
}