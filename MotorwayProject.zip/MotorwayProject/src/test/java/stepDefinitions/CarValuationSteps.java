import hooks.BasePage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import pageObjects.CarValuationPage;
import utilities.TextFileParser;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.util.*;

public class CarValuationSteps {

    private final WebDriver driver = BasePage.getDriver();
    private final CarValuationPage carValuationPage = new CarValuationPage(driver);
    private final Map<String, String[]> expectedOutput = new HashMap<>();
    private List<String> registrationNumbers = new ArrayList<>();
    private final String filePath = "C:\\Users\\Nelly\\IdeaProjects\\MotorwayProject\\src\\test\\resources\\features\\car_input.txt";

    @Given("car registration numbers are extracted from an input file")
    public void carRegistrationNumbersAreExtractedFromAnInputFile() throws IOException {
        // Load expected outputs
        loadExpectedOutput();

        // Use FileParserFactory to get the specific parser and extract registrations
        Object parser = TextFileParser.FileParserFactory.getParser(filePath);

        if (parser instanceof TextFileParser.TextFileParser) {
            registrationNumbers = ((TextFileParser.TextFileParser) parser).extractRegistrationNumbers(filePath);
        } else if (parser instanceof TextFileParser.CSVFileParser) {
            registrationNumbers = ((TextFileParser.CSVFileParser) parser).extractRegistrationNumbers(filePath);
        } else {
            throw new UnsupportedOperationException("Unsupported parser type.");
        }

        System.out.println("Extracted Registrations: " + registrationNumbers);
    }

    @When("user searches for each registration number")
    public void userSearchesForEachRegistrationNumber() {
        driver.get("https://motorway.co.uk/"); // Replace with actual URL

        for (String registration : registrationNumbers) {
            carValuationPage.fillCarRegistration(registration);
            carValuationPage.clickValueYourCar();
            driver.navigate().refresh();
        }
    }

    @Then("search result should match the expected outcome")
    public void searchResultShouldMatchTheExpectedOutcome() {
        for (String registration : registrationNumbers) {
            String[] expectedDetails = expectedOutput.get(registration);
            String actualDetails = carValuationPage.getCarDetails();

            Assert.assertTrue(actualDetails.contains(expectedDetails[0]),
                    "Variant registration does not match for: " + registration);
            Assert.assertTrue(actualDetails.contains(expectedDetails[1]),
                    "Make and model do not match for: " + registration);
            Assert.assertTrue(actualDetails.contains(expectedDetails[2]),
                    "Year does not match for: " + registration);
        }
    }

    private void loadExpectedOutput() {
        expectedOutput.put("SG18 HTN", new String[]{"Volkswagen Golf SE Navigation TSI EVO", "2018"});
        expectedOutput.put("AD58 VNF", new String[]{"BMW 120D M Sport", "2008"});
        expectedOutput.put("BW57 BOF", new String[]{"Toyota Yaris T2", "2008"});
        expectedOutput.put("KT17 DLX", new String[]{"Skoda Superb Sportline TDI S-A", "2017"});
    }
}